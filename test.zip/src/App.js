import React, { Component } from 'react';
import './App.css';


import 'primereact/resources/themes/nova-light/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';

import  ProgramOutcomeStandard from './components/ProgramOutcomeStandard' 

class App extends Component {
  render() {
    return (
      <div className="App">
        <ProgramOutcomeStandard />
      </div>
    );
  }
}

export default App;
